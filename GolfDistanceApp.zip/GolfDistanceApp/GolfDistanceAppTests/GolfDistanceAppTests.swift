//
//  GolfDistanceAppTests.swift
//  GolfDistanceAppTests
//
//  Created by Conor Griffiths on 18/01/2025.
//

import Testing

struct GolfDistanceAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
